const express = require("express");
const app = express();
const mongoose = require("mongoose");
const multer = require("multer");
const cors = require("cors");

app.use(express.json());
app.use(cors());

//mongodb connection
const mongoUrl =
  "mongodb+srv://hari:hari@cluster0.hsmpfuf.mongodb.net/newfileulpad?retryWrites=true&w=majority";

mongoose
  .connect(mongoUrl, {
    useNewUrlParser: true,
  })
  .then(() => {
    console.log("Connected to database");
  })
  .catch((e) => console.log(e));

// ImageDetails Schema
const ImageDetailsScehma = new mongoose.Schema(
  {
    title: String,
    description: String,
    image: String,
  },
  {
    collection: "ImageDetails",
  }
);

const Images = mongoose.model("ImageDetails", ImageDetailsScehma);

// multer configuration
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, "../src/images/");
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now();
    cb(null, uniqueSuffix + file.originalname);
  },
});

const upload = multer({ storage: storage });

// Routes
app.get("/", async (req, res) => {
  res.send("Success!!!!!!");
});

app.post("/upload-image", upload.single("image"), async (req, res) => {
  console.log(req.body);
  const { title, description } = req.body;
  const imageName = req.file.filename;

  try {
    await Images.create({ title, description, image: imageName });
    res.json({ status: "ok" });
  } catch (error) {
    res.json({ status: error });
  }
});

app.get("/get-image", async (req, res) => {
  try {
    Images.find({}).then((data) => {
      res.send({ status: "ok", data: data });
    });
  } catch (error) {
    res.json({ status: error });
  }
});

app.listen(5000, () => {
  console.log("Server Started on 5000");
});
